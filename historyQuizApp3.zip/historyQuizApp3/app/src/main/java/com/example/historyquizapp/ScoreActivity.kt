package com.example.historyquizapp

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class ScoreActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_score)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Get data from Intent
        val score = intent.getIntExtra("SCORE", 0)
        val totalQuestions = intent.getIntExtra("TOTAL_QUESTIONS", 5)
        val questions = intent.getStringArrayListExtra("QUESTIONS") ?: arrayListOf()
        val correctAnswers = intent.getStringArrayListExtra("CORRECT_ANSWERS") ?: arrayListOf()
        val userAnswers = intent.getStringArrayListExtra("USER_ANSWERS") ?: arrayListOf()

        // Find views
        val textScore = findViewById<TextView>(R.id.textScore)
        val textFeedback = findViewById<TextView>(R.id.textFeedback)
        val txtReview = findViewById<TextView>(R.id.txtReview)
        val btnReview = findViewById<Button>(R.id.btnReview)
        val btnExit = findViewById<Button>(R.id.btnExit)
        val btnRestart = findViewById<Button>(R.id.btnRestart)

        // Show score
        textScore.text = "You got $score out of $totalQuestions correct"

        // Show feedback based on score
        textFeedback.text = if (score >= 3) "Great Job!" else "Keep practising!"

        // Initially hide review text
        txtReview.visibility = View.GONE

        btnReview.setOnClickListener {
            txtReview.visibility = View.VISIBLE
            val reviewBuilder = SpannableStringBuilder()

            for (i in questions.indices) {
                val question = "Question: ${questions[i]}\n"
                val userAnswer = userAnswers.getOrElse(i) { "Not Answered" }
                val correctAnswer = correctAnswers.getOrElse(i) { "N/A" }
                val isCorrect = userAnswer == correctAnswer
                val resultText = if (isCorrect) "Correct" else "Incorrect"
                val resultColor = if (isCorrect) Color.GREEN else Color.RED

                reviewBuilder.append(question)
                reviewBuilder.append("Your Answer: $userAnswer (")

                val start = reviewBuilder.length
                reviewBuilder.append(resultText)
                val end = reviewBuilder.length

                reviewBuilder.setSpan(
                    ForegroundColorSpan(resultColor),
                    start,
                    end,
                    Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
                )
                reviewBuilder.append(")\n\n")
            }

            txtReview.text = reviewBuilder
        }

        btnRestart.setOnClickListener {
            val intent = Intent(this, QuestionActivity::class.java)
            startActivity(intent)
            finish()
        }

        btnExit.setOnClickListener {
            finishAffinity() // Close the app completely
        }
    }
}








