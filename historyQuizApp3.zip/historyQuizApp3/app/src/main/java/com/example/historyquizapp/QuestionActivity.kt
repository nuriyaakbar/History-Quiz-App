package com.example.historyquizapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class QuestionActivity : AppCompatActivity() {

    private val questions = arrayOf(
        "1. The Nile River was a major source of life and transportation in Ancient Egypt.",
        "2. Ancient Egyptians did not believe in an afterlife.",
        "3. The pyramids of Giza were built to be tombs for the kings.",
        "4. Women were not allowed to own property in Ancient Egypt.",
        "5. Ancient Egyptian children did not receive a formal education."
    )
    private val answers = booleanArrayOf(true, false, true, false, false)

    private var currentQuestionIndex = 0
    private var score = 0
    private val userAnswers = ArrayList<String>()

    private lateinit var txtQuestion: TextView
    private lateinit var btnTrue: Button
    private lateinit var btnFalse: Button
    private lateinit var btnNext: Button
    private lateinit var txtFeedback: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_question)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        txtQuestion = findViewById(R.id.txtQuestion)
        btnTrue = findViewById(R.id.btnTrue)
        btnFalse = findViewById(R.id.btnFalse)
        btnNext = findViewById(R.id.btnNext)
        txtFeedback = findViewById(R.id.txtFeedback)

        loadQuestion()

        btnTrue.setOnClickListener { checkAnswer(true) }
        btnFalse.setOnClickListener { checkAnswer(false) }

        btnNext.setOnClickListener {
            currentQuestionIndex++
            if (currentQuestionIndex < questions.size) {
                loadQuestion()
                txtFeedback.text = "" // Clear feedback
                btnNext.isEnabled = false
            } else {
                // After final question, go to ScoreActivity
                val intent = Intent(this, ScoreActivity::class.java)
                intent.putExtra("SCORE", score)
                intent.putExtra("TOTAL_QUESTIONS", questions.size)
                intent.putStringArrayListExtra("QUESTIONS", ArrayList(questions.toList()))
                intent.putStringArrayListExtra("USER_ANSWERS", userAnswers)
                intent.putStringArrayListExtra("CORRECT_ANSWERS", ArrayList(answers.map { it.toString() }))

                startActivity(intent)
                finish()
            }
        }

        btnNext.isEnabled = false
    }

    private fun loadQuestion() {
        txtQuestion.text = questions[currentQuestionIndex]
        btnTrue.isEnabled = true
        btnFalse.isEnabled = true
    }

    private fun checkAnswer(userAnswer: Boolean) {
        val correctAnswer = answers[currentQuestionIndex]

        userAnswers.add(userAnswer.toString())

        if (userAnswer == correctAnswer) {
            txtFeedback.text = "Correct!"
            score++
        } else {
            txtFeedback.text = "Incorrect."
        }

        btnNext.isEnabled = true
        btnTrue.isEnabled = false
        btnFalse.isEnabled = false
    }
}















